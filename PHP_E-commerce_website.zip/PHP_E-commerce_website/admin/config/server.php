<?php
### SET TIME ZONE
date_default_timezone_set("Asia/Dhaka");

### SET SMTP CONFIGURATION
$GLOBALS['SMTPHOST'] = "mail.servername.com";
$GLOBALS['SMTPUSER'] = "noreply@servername.com";
$GLOBALS['SMTPPORT'] = "465";
$GLOBALS['SMTPAUTH'] = "ssl";
$GLOBALS['SMTPPASS'] = "abc123";
?>